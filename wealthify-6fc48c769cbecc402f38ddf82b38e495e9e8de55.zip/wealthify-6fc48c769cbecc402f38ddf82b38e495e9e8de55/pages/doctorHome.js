import React from "react";
import DoctorDashboard from "../components/DoctorDashboard";
import EachPatientDetails from "../components/EachPatientDetails";

const doctorHome = () => {
  return <DoctorDashboard />;
};

export default doctorHome;
