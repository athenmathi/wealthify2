import React from "react";
import Recipe from "../components/Recipe";

import Recipes from "../components/Recipes";
const recipe = () => {
  return (
    <>
      <Recipe />
      <Recipes />
    </>
  );
};

export default recipe;
