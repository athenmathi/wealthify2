import React from "react";
import EachPatientDetails from "../components/EachPatientDetails";

const eachPatient = () => {
  return <EachPatientDetails />;
};

export default eachPatient;
