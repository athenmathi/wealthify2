import React from "react";
import NutritionDb from "../components/NutritionDb";

const Nutrition = () => {
  return <NutritionDb />;
};

export default Nutrition;
