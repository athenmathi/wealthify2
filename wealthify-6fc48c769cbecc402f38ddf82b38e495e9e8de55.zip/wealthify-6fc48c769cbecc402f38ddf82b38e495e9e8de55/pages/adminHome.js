import React from "react";
import DoctorHome from "../components/DoctorHome";

const adminHome = () => {
  return <DoctorHome />;
};

export default adminHome;
