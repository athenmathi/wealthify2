import React from "react";
import AssessmentFormContainer from "../assets/wrappers/AssessmentFormContainer";

const assessment = () => {
  return <AssessmentFormContainer />;
};

export default assessment;
