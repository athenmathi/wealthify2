import styled from "styled-components";

const Wrappers = styled.div``;

export default Wrappers;
