import React from "react";
import rightCheveron from "../assets/image/rightCheveron.svg";
import Image from "next/image";
const RightCheveron = () => {
  return <Image src={rightCheveron} />;
};

export default RightCheveron;
