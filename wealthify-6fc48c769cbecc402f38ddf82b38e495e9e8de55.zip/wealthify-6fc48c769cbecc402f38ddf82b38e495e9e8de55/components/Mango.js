import React from "react";

const Mango = () => {
  return <Wrappers></Wrappers>;
};

export default Mango;
